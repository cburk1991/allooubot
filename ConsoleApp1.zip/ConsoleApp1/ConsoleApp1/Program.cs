using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AlloouBot;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = string.Empty;
            TwitchChatBot bot = new TwitchChatBot();
            bot.Connect();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("To disconnect the bot, type 'Q' at any time");
            Console.ForegroundColor = ConsoleColor.Gray;

            while(!str.Equals("Q", StringComparison.InvariantCultureIgnoreCase))
            {
                str = Console.ReadLine();
            }

            bot.Disconnect();
            Console.ReadLine();
        }
    }
}
